# Article-style POS rPPG pipeline

This is a modernized, usable replacement for the old POS pulse-extraction script.
It follows the 2025 article's described rPPG estimation setup as closely as possible
in a standalone script:

- MediaPipe Face Mesh instead of dlib's old 68-point predictor.
- Facial ROI options from the article:
  - `face`: facial skin region excluding eyes and mouth.
  - `selected`: forehead + cheeks.
  - `full-frame`: whole frame.
- Default RGB extraction from the 100 MediaPipe landmarks used in the article's
  released code (`forehead`, `cheeks`, and `nose` patches).
- 8-second overlapping windows with 1-second stride.
- 6th-order Butterworth bandpass filter from `0.65` to `4.0` Hz.
- POS BVP extraction with the 1.6-second POS internal window.
- Welch PSD BPM estimation in the `0.65` to `4.0` Hz range.
- Optional article-style lightweight video modifications.

## Install

Use Python 3.10+ if possible.

```bash
python3 -m venv .venv
source .venv/bin/activate
python3 -m pip install -r requirements.txt
```

The first run downloads Google's public `face_landmarker.task` model to
`~/.cache/article_pos_pipeline/face_landmarker.task`. This is needed by the
newer MediaPipe Tasks API. If your installed MediaPipe still includes the older
`mp.solutions.face_mesh` API, the script will use that instead.

## Estimate heart rate with POS

```bash
python article_pos_pipeline.py extract \
  --video /path/to/input_video.mp4 \
  --output-prefix outputs/input_video_pos
```

Outputs:

- `outputs/input_video_pos.summary.json`: video-level summary and mean/median BPM.
- `outputs/input_video_pos.windows.csv`: per-window BPM estimates.
- `outputs/input_video_pos.rgb.npy`: extracted RGB trace.
- `outputs/input_video_pos.bvp.npy`: extracted POS BVP signal.

Recommended default:

```bash
python article_pos_pipeline.py extract \
  --video data/sample_video.avi \
  --output-prefix outputs/sample_pos \
  --rgb-mode patches \
  --roi face \
  --window-seconds 8 \
  --stride-seconds 1 \
  --min-hz 0.65 \
  --max-hz 4.0
```

`--rgb-mode patches` uses the article's 100 landmark patches. `--roi` is ignored
for patch RGB extraction but kept in the summary. Use `--rgb-mode mask` if you
want a single ROI average instead.

## Modify a video like the article

Apply the article's best-performing privacy method, 20-frame sliding time averaging,
to the face ROI:

```bash
python article_pos_pipeline.py modify \
  --input /path/to/input_video.mp4 \
  --output outputs/input_video_tas.mp4 \
  --method time-average-sliding \
  --roi face \
  --time-window-frames 20
```

Other methods:

- `median`
- `gaussian`
- `bilateral`
- `gaussian-noise`
- `saltpepper-noise`
- `poisson-noise`
- `pepper-noise`
- `speckle-noise`
- `time-average-cumulative`
- `time-average-sliding`

Article-style defaults are `--kernel-size 5`, bilateral sigma values of `75`, and
`--time-window-frames 20`.

## Important scientific limitations

This script makes the old code usable and aligns it with the article's method
description, but exact reproduction of the paper's reported numbers still requires:

- The same LGI-PPGI videos and ground-truth finger PPG signals.
- The paper's full released repository/pyVHR configuration.
- Matching evaluation code for BPM error, MSE, and overall score.
- Same available subjects/activities and same versions of dependencies.

Do not treat a single video's BPM output as medically exact. rPPG is sensitive to
lighting, motion, compression, skin visibility, and camera frame rate.

The provided `data/sample_video.avi` in the article repository is only about 5
seconds long, so the default 8-second article window cannot run on it. Use a
longer video for the true article settings, or add `--window-seconds 3` only for
a smoke test.
